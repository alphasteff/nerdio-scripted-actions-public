## Version
1.0, 10.02.2026

## Exclusions
defragsvc, removed defragsvc because FSLogix need